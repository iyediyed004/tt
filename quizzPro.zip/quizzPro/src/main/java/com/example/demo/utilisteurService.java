package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class utilisteurService {

	@Autowired
	public utilisateurRepository utilisateurRepository;
	
	public Optional<utilisateur> getUtilisateurById(long id) {
		// TODO Auto-generated method stub
		return utilisateurRepository.findById(id);
	}

	public void deleteUtilisateur(long id) {
		utilisateurRepository.deleteById(id);
		
	}
	
	public void validUser(long userId) {
	    Optional<utilisateur> optionalUser = utilisateurRepository.findById(userId);

	    if (optionalUser.isPresent()) {
	        utilisateur user = optionalUser.get();

	        user.setStatuts("accepte");

	        utilisateurRepository.save(user);
	    } else {
	        throw new RuntimeException("User not found with ID: " + userId);
	    }
	}


	public List<utilisateur> findByNom(String query) {
        return utilisateurRepository.findByNom(query);
    }



	public List<utilisateur> getAllUtilisateurs() {
		// TODO Auto-generated method stub
		return utilisateurRepository.findAll();
	}
	
	public List<utilisateur> findByStatus(String status){
		return utilisateurRepository.findByStatuts(status);
		
	}

	public utilisateur addUtilisateur(utilisateur utilisateur) {
		System.out.println("user "+utilisateur.getStatuts());
		return utilisateurRepository.save(utilisateur);
	}

	public utilisateur updateUtilisateur(long id, utilisateur utilisateurDetails) {
	    // Check if the utilisateur with the given ID exists
	    Optional<utilisateur> existingUtilisateurOptional = utilisateurRepository.findById(id);

	    // If the utilisateur is present, update its fields and save it
	    if (existingUtilisateurOptional.isPresent()) {
	        utilisateur existingUtilisateur = existingUtilisateurOptional.get();

	        // Update only the fields that are non-null in utilisateurDetails
	        if (utilisateurDetails.getNom() != null) {
	            existingUtilisateur.setNom(utilisateurDetails.getNom());
	        }
	        if (utilisateurDetails.getPrenom() != null) {
	            existingUtilisateur.setPrenom(utilisateurDetails.getPrenom());
	        }
	        if (utilisateurDetails.getEmail() != null) {
	            existingUtilisateur.setEmail(utilisateurDetails.getEmail());
	        }
	        if (utilisateurDetails.getNum() != null) {
	            existingUtilisateur.setNum(utilisateurDetails.getNum());
	        }
	        if (utilisateurDetails.getAdresse() != null) {
	            existingUtilisateur.setAdresse(utilisateurDetails.getAdresse());
	        }
	        if (utilisateurDetails.getMotDePasse() != null) {
	            existingUtilisateur.setMotDePasse(utilisateurDetails.getMotDePasse());
	        }
	        if (utilisateurDetails.getdate() != null) {
	            existingUtilisateur.setdate(utilisateurDetails.getdate());
	        }
	        if (utilisateurDetails.getRole() != null) {
	            existingUtilisateur.setRole(utilisateurDetails.getRole());
	        }

	        // Save the updated utilisateur back to the database
	        return utilisateurRepository.save(existingUtilisateur);
	    } else {
	        // If the utilisateur doesn't exist, throw an exception
	        throw new RuntimeException("Utilisateur not found with ID: " + id);
	    }
	}

}
