package com.example.demo;


import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/utilisateurs")
public class utilisateurController {

    private static final Logger logger = LoggerFactory.getLogger(utilisateurController.class);
    private utilisteurService utilisateurService;
    
    @Autowired
    public utilisateurController(utilisteurService utilisateurService) {
        this.utilisateurService = utilisateurService;
    }
    
    
    @GetMapping("/users/{status}")
    public List<utilisateur> getAcceptedUser(@PathVariable String status){
		return utilisateurService.findByStatus(status);
    	
    }
    
    @PutMapping("/valid/{id}")
    public ResponseEntity<String> validUser(@PathVariable long id) {
        try {
            utilisateurService.validUser(id);
            return ResponseEntity.ok("User status updated to 'accepte'");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping
    public List<utilisateur> getAllUtilisateurs() {
        return utilisateurService.getAllUtilisateurs();
    }

    @GetMapping("/{id}")
    public utilisateur getUtilisateurById(@PathVariable Long id) {
    	utilisateur user = utilisateurService.getUtilisateurById(id).get();
    	System.out.println(user);
    	return user;
    }

    @PutMapping("/{id}")
    public utilisateur updateUtilisateur(@PathVariable long id, @RequestBody utilisateur utilisateur) {
        logger.info("Requête PUT reçue pour ID: {}", id);
        logger.info("Données reçues: {}", utilisateur);
        

        try {
            utilisateur updatedUtilisateur = utilisateurService.updateUtilisateur(id, utilisateur);
            logger.info("Mise à jour réussie pour l'utilisateur avec ID: {}", id);
            return updatedUtilisateur;
        } catch (Exception e) {
            logger.error("Erreur lors de la mise à jour de l'utilisateur avec ID: {}", id, e);
            throw e;
        }
    }

    @PostMapping
    public utilisateur signupemploye(@RequestBody utilisateur utilisateur) {
        return utilisateurService.addUtilisateur(utilisateur);
    }

    @DeleteMapping("/{id}")
    public void deleteUtilisateur(@PathVariable Long id) {
    	utilisateurService.deleteUtilisateur(id);
    }

    @GetMapping("/search")
    public List<utilisateur> searchUtilisateurs(@RequestParam String query) {
        return utilisateurService.findByNom(query);
    }
}
